<template>
  <section>
    <h1>404</h1>
    <p>Stranica ne postoji.</p>
    <RouterLink to="/">Natrag na Home</RouterLink>
  </section>
</template>
