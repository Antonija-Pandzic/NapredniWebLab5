<template>
  <section>
    <h1>About</h1>
    <p>
      Aplikacija demonstrira Vue 3 značajke: router, Pinia store, komponente,
      evente, computed, lifecycle i async dohvat.
    </p>
  </section>
</template>
