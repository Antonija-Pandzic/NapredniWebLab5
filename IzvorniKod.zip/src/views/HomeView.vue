<script setup>
const appTitle = "Task Planner";
</script>

<template>
  <section>
    <h1>{{ appTitle }}</h1>
    <p>Jednostavna SPA aplikacija za planiranje zadataka.</p>
  </section>
</template>
